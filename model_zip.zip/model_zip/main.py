from model import attention_lstm_random

if __name__ == "__main__":
    # initialize the model
    att = attention_lstm_random()
    att_model = att.att_model

    # inference,predict
    test_txt = "well child enjoying it and mother drying dish and little boy fall careful oh dishwashing and little boy trying get something outof box imagine it cookie box cookie and and stool it turned yet way it two leg it much longer reaching cookie jar dishwashing evidently hafta dry dish wash think"
    Y_pred = att_model.predict(att.preprocess_text(test_txt))
    probability = Y_pred[0][0]

    print("Probability of the text being a dementia is: ", probability)
